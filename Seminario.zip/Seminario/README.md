![header](https://capsule-render.vercel.app/api?type=waving&color=#6A5ACDheight=300&section=header&text=capsule%20render&fontSize=90)


<div align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Nosifer&size=35&pause=1000&color=6A5ACD&center=verdadeiro&vCenter=verdadeiro&repeat=verdadeiro&random=falso&width=613&height=60&lines=Semin%C3%A1rio+Tem%C3%A1tico+VIII" alt="Typing SVG" /></a>
</div>


# Apresetação do seminario tematico

<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=&height=120&section=footer"/>
