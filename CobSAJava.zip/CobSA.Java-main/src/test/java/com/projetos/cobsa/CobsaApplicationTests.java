package com.projetos.cobsa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CobsaApplicationTests {

	@Test
	void contextLoads() {
	}

}
